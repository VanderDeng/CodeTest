package com.vcg.zombie.model.entity;

public abstract class Creatures {
    String positionX;
    String positionY;



}
