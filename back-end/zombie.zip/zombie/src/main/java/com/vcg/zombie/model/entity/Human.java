package com.vcg.zombie.model.entity;

public class Human  extends Creatures{


}
