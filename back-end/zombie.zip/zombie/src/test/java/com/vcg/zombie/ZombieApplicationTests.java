package com.vcg.zombie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZombieApplicationTests {

	@Test
	void contextLoads() {
	}

}
